function save_tikz(filename, markersize)
lh = findall(gcf, 'type', 'line');
if nargin<2
    markersize = 6.25;
end
set(lh, 'MarkerSize', markersize);
filename = sprintf('../tex/plots/%s.tikz', filename);
if 1;
matlab2tikz(filename, 'height', '\figheight', 'width', '\figwidth', ...
    'showInfo', false, 'checkForUpdates', false, ...
    'extraTikzpictureOptions', 'matlab2tikz picture', ...
    'parseStrings', false);
end
