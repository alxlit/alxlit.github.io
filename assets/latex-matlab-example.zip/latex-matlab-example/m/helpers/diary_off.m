function diary_off()
diary off;