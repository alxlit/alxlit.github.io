function diary_on(filename);
f = sprintf('./diary/%s', filename);
delete(f);
diary(f);