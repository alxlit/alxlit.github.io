function indices = resample_for_tikz(x, n)

% resample_for_tikz_3(x, n)
%
% Tries to resample a waveform to fewer points, while preserving (as much
% as possible) the original shape. Can help cut down TikZ compile time.

m = length(x);
indices = zeros(1, n);
num_blocks = 100;
energy = abs(x).^2;
block_size = ceil(m / num_blocks);
blocks = min(block_size * (0:num_blocks), m);
block_energy = sum(energy) / num_blocks;
samples_per_block = floor(n / num_blocks);

j = 1;
for k = 2:num_blocks+1
    a = blocks(k-1)+1;
    b = blocks(k);
    
    % sort points by energy
    [~, ix] = sort(energy(a:b) / block_energy);
    
    p = length(ix);
    
    % sample (sort of) logarithmically
    l = linspace(1, p, samples_per_block);
    l = floor(p*log(l)/log(p));
    l(1) = 1;
    
    indices(j:j+samples_per_block-1) = a + sort(ix(l));
    j = j+m;
end

% ah some are wasted oh well
indices = indices(indices ~= 0);

