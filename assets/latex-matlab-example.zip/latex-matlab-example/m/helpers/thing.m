function thing(name, thing)
fprintf('%s =\n', name)
if isstruct(thing)
    strucdisp(thing);
else
    disp(thing);
end