clear all;
addpath('helpers', 'matlab2tikz');

db = @(x) 20*log10(abs(x));

n = 2^10;
x = randn(1,n);
fs = 1;
nfft = 2^nextpow2(n);
fmax = n*fs;
f = linspace(-fs/2,fs/2,nfft);
esd = fftshift(fft(x,nfft));

figure 1;
clf; hold on; grid on;
plot(f/fs,db(esd));
xlim([-1/2 1/2]);
xlabel('frequency (fractional)');
ylabel('magnitude (dB)');
title('Energy spectral density of x(t)');
save_tikz('example');

